package com.tryout.microservices.currencyexchangeser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyExchangeSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
