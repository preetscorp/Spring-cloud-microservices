package com.tryout.microservices.currencyconversionser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
